import javax.swing.JOptionPane;

/**
 *  This class controls the game play
 * @author Susie Smart
 *
 */
public class GamePlay {
	
	// Instance variables
	private Player p1, p2;
	private int turn, p1PlacementCount, p2PlacementCount;
	// Constants set at the start of the program
	private final int rows = 10;
	private final int cols = 10;
	private final int noOfShips = 5;
	
	/**
	 *  GamePlay Constructor
	 */
	public GamePlay(){
		// Initialise player counters 
		p1PlacementCount = 0;
		p2PlacementCount = 0;
		// Initialise two separate player objects
		p1 = new Player(rows,cols);
		p2 = new Player(rows,cols);
		// Set turn to player 1 
		turn = 1;
	}
	
	/**
	 * Method that allows the user to lay their ships out on the grid
	 * @param p Integer representing either player 1 or 2
	 * @param x X-position of the starting point for the ship
	 * @param y Y-position of the starting point for the ship
	 */
	public void layoutShips(int p, int x, int y, Boolean horiz){
		
		// First check if the ship will go off the grid or ovralap another boat
		if (checkForEdges(p, x , y, horiz) == true && checkForOthers(p, x, y, horiz) == true && horiz == true){
			if ( p == 1){
				p1.addShip(p1PlacementCount,x, y, true);
				p1PlacementCount++;
			}
			else if (p ==2){
				p2.addShip(p2PlacementCount,x,y, true );
				p2PlacementCount++;
			}
		}
		else if (checkForEdges(p, x , y, horiz) == true && checkForOthers(p, x, y, horiz) == true && horiz == false){
			if ( p == 1){
				p1.addShip(p1PlacementCount,x, y, false);
				p1PlacementCount++;
			}
			else if (p ==2){
				p2.addShip(p2PlacementCount,x,y, false);
				p2PlacementCount++;
			}
		}	
	}
	
	/**
	 * Method that allows a player to take a turn
	 * @param p Integer representing either player 1 or 2
	 * @param x X-position of the starting point for the ship
	 * @param y Y-position of the starting point for the ship
	 * @return Returns either a 1 or a 0 if it was a hit or a miss
	 */
	public int playerTurn(int p, int x, int y){
		
		// First check that the player has not already taken a shot in the cell
		if (checkForPrevious(p,x,y) == true){
			if (p == 2){	
				// Check if the other player will be hit
				if (p1.wasIHit(x, y) == 1){
					// Add hit to players tracking grid and to opponents own grid
					p2.takeAShot(x, y, " X ");
					p1.receiveHit(x, y, " X ");
					return 1;	
				}
				else  {
					// Add miss to players tracking grid and to opponents own grid
					p2.takeAShot(x, y, " 0 ");
					p1.receiveHit(x, y, " 0 ");
					return 0;
				}
			}
			else {
				// First check that the player has not already taken a shot in the cell
				if (p2.wasIHit(x, y)==1){
					// Add hit to players tracking grid and to opponents own grid
					p1.takeAShot(x, y, " X ");
					p2.receiveHit(x, y, " X ");
					return 1;	
				}
				else {
					// Add hit to players tracking grid and to opponents own grid
					p1.takeAShot(x, y, " 0 ");
					p2.receiveHit(x, y, " 0 ");
					return 0;
				}
			}
		}
		// Return 3 if a previous shot was in the cell
		return 3;
	}

	/**
	 * Method which checks if there is already a ship where the player
	 * is trying to place their current ship.
	 * @param p Integer representing either player 1 or 2
	 * @param x X-position of the starting point for the ship
	 * @param y Y-position of the starting point for the ship
	 * @return true or false depending on if their is another ship
	 */
	public boolean checkForOthers (int p, int x, int y, boolean horiz){
		
		if ( p == 1 && horiz == true){
			// Get both the players current own grid and the ship array
			String[][] temp = p1.playerGrid();
			int p1Ships[] = p1.getShipArray();
			// For the length of the current ship check that there is no ship symbol
			for (int i = 0; i < p1Ships[p1PlacementCount]; i++){
				if (temp[x][y+i].equals("   ")){	
				}
				else {
					JOptionPane.showMessageDialog(null,"There was already a ship there! Please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
					return false;
				}
			}	
		}
		if ( p == 2 && horiz == true){
			// Get both the players current own grid and the ship array
			String[][] temp = p2.playerGrid();
			int p2Ships[] = p2.getShipArray();
			// For the length of the current ship check that there is no ship symbol
			for (int j = 0; j < p2Ships[p2PlacementCount]; j++){
				if (temp[x][y+j].equals("   ")){
				}
				else {
					JOptionPane.showMessageDialog(null,"There was already a ship there! Please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
					return false;
				}	
			}
		}
		if ( p == 1 && horiz == false){
			// Get both the players current own grid and the ship array
			String[][] temp = p1.playerGrid();
			int p1Ships[] = p1.getShipArray();
			// For the length of the current ship check that there is no ship symbol
			for (int i = 0; i < p1Ships[p1PlacementCount]; i++){
				if (temp[x+i][y].equals("   ")){	
				}
				else {
					JOptionPane.showMessageDialog(null,"There was already a ship there! Please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
					return false;
				}
			}	
		}
		if ( p == 2 && horiz == false){
			// Get both the players current own grid and the ship array
			String[][] temp = p2.playerGrid();
			int p2Ships[] = p2.getShipArray();
			// For the length of the current ship check that there is no ship symbol
			for (int j = 0; j < p2Ships[p2PlacementCount]; j++){
				if (temp[x+j][y].equals("   ")){
				}
				else {
					JOptionPane.showMessageDialog(null,"There was already a ship there! Please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
					return false;
				}	
			}
		}
		
		
		return true;
	}
		
	/**
	 *  Mehtod that checks if the ship will go off the edge of the grid
	 *  when it is placed.
	 * @param p Integer representing either player 1 or 2
	 * @param x X-position of the starting point for the ship
	 * @param y Y-position of the starting point for the ship
	 * @return true or false depending on if the ship will fit on the grid
	 */
	public boolean checkForEdges (int p, int x, int y, boolean horiz){

		if ( p == 1 && horiz == true){
			// Get the ship array
			int p1Ships[] = p1.getShipArray();
			// Add the ship length to the y position of the placement and check if this exceeds the grid columns
			if (p1Ships[p1PlacementCount]+y>rows){
				JOptionPane.showMessageDialog(null,"You placed the ship too near the edge, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		if ( p == 2 && horiz == true){
			// Get the ship array
			int p2Ships[] = p1.getShipArray();
			// Add the ship length to the y position of the placement and check if this exceeds the grid columns
			if (p2Ships[p2PlacementCount]+y>rows){
				JOptionPane.showMessageDialog(null,"You placed the ship too near the edge, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		if ( p == 1 && horiz == false){
			// Get the ship array
			int p1Ships[] = p1.getShipArray();
			// Add the ship length to the y position of the placement and check if this exceeds the grid columns
			if (p1Ships[p1PlacementCount]+x>cols){
				JOptionPane.showMessageDialog(null,"You placed the ship too near the edge, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		if ( p == 2 && horiz == false){
			// Get the ship array
			int p2Ships[] = p1.getShipArray();
			// Add the ship length to the y position of the placement and check if this exceeds the grid columns
			if (p2Ships[p2PlacementCount]+x>cols){
				JOptionPane.showMessageDialog(null,"You placed the ship too near the edge, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}

		return true;
	}
	
	/**
	 *  Method to check if the player is shooting in a cell they have
	 *  previously taken a shot in.
	 * @param p Integer representing either player 1 or 2
	 * @param x X-position of the shot
	 * @param y Y-position of the shot
	 * @return True or false depending on whether their was a previous shot there
	 */
	public boolean checkForPrevious(int p, int x, int y){
		
		if ( p == 1 ){
			// Get the players current tracking grid
			String p1Track[][] = p1.playerTracker();
			// Check if the current shot location already has a hit or miss symbol and display an error if so
			if (p1Track[x][y].equals(" 0 ") || p1Track[x][y].equals(" X ")){
				JOptionPane.showMessageDialog(null,"You already fired there, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		else if ( p == 2 ){
			// Get the players current tracking grid
			String p2Track[][] = p2.playerTracker();
			// Check if the current shot location already has a hit or miss symbol and display an error if so
			if (p2Track[x][y].equals(" 0 ") || p2Track[x][y].equals(" X ")){
				JOptionPane.showMessageDialog(null,"You already fired there, please try again", "Input Error",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Method to get the current grid from the player and return it.
	 * @param p Integer representing either player 1 or 2
	 * @return String array representing the players own grid
	 */
	public String[][] getMyGrid(int p){

		String[][] currentGrid;
		if (p == 1){
			// Get current players own grid and return it
			currentGrid = p1.playerGrid();	
			return currentGrid;	
		}
		else{
			// Get current players own grid and return it
			currentGrid = p2.playerGrid();
			return currentGrid;	
		}	
	}
	
	/**
	 * Method to get the current tracking grid from the player and return it.
	 * @param p Integer representing either player 1 or 2
	 * @return String array representing the players tracking grid
	 */
	public String[][] getMyTracker(int p){
		
		String[][] currentTracker;
		if (p == 1){
			// Get current players tracking grid and return it
			currentTracker = p1.playerTracker();	
			return currentTracker;	
		}
		else{
			// Get current players tracking grid and return it
			currentTracker = p2.playerTracker();
			return currentTracker;	
		}	
	}
	
	/**
	 * Method to return the number of ships the 
	 * player has placed
	 * @param p Integer representing either player 1 or 2
	 * @return Integer representing the number of ships placed
	 */
	public int getPlacementCount(int p){

		if (p == 1){
			return p1PlacementCount;
		}
		else {
			return p2PlacementCount;
		}
	}
	
	/**
	 * Method to add to the number of ships the 
	 * player has placed
	 * @param p Integer representing either player 1 or 2
	 */
	public void addToCount(int p){
		
		if (p == 1){
			p1PlacementCount++;
		}
		else {
			p2PlacementCount++;
		}
	}
	
	/**
	 * 
	 */
	public int getShipLength(int p, int i){
		
		int lengthArray[];
		int length;
		
		if (p ==1 ){
			lengthArray = p1.getShipArray();
			length = lengthArray[i];
		}
		else {
			lengthArray = p2.getShipArray();
			length = lengthArray[i];
		}
	
		return length;
	}
	
	/**
	 *  Method which swaps the turn from the current
	 *  player to their opponent
	 * @param p Integer representing either player 1 or 2
	 */
	public void swapTurn(int p){
		
		if (p == 1){
			turn = 2;
		}
		else if (p == 2){
			turn = 1;
		}
	}
	
	// Return the number of rows
	public int getRows(){
		return rows;
	}
	// Return the number of columns
	public int getCols(){
		return cols;
	}
	// Return the number of ships
	public int getNoOfShips(){
		return noOfShips;
	}
	// Return the current players turn
	public int getTurn(){
		return turn;
	}
}