/** Defines an object representing a single player.
 *  The player class contains the player own grid
 *  and their tracking grid.
 */
public class Player {
	
	// Instance variables
	private String [][] myGrid;
	private String [][] trackingGrid;
	// Constants set at the start of the program
	private final int [] ships = {5,4,3,3,2};
	private final int rows, cols;
	
	
	/**
	 * Player constructor
	 * @param r Number of rows in the grids. Set in the GamePlay Class
	 * @param c Number of columns in the grids. Set in the GamPlay Class
	 */
	public Player(int r, int c){
		
		// Initialise rows/columns and set the two grids array size
		rows = r;
		cols = c;
		myGrid = new String[rows][cols];
		trackingGrid = new String[rows][cols];
		
		// Set the players own grid to contain empty space
		int i = 0;
		for (int j = 0; j<rows; j++){
			for ( i = 0; i < cols; i ++){
				myGrid[j][i] = "   ";
			}
			i = 0;
		}

		// Set the players tracking grid to contain empty space
		int n = 0;
		for (int m = 0; m<rows; m++){
			for ( n = 0; n < cols; n ++){
				trackingGrid[m][n] = "   ";
			}
			n = 0;
		}	
	}
	
	/**
	 * Method to add ships to the players own grid
	 * @param s Ship number 
	 * @param x	X-position in grid
	 * @param y Y-position in grid
	 */
	public void addShip(int s, int x, int y, boolean horizontal){
		
		// Get the length of the current ship to be placed
		int currentShip = ships[s];
		
		if (horizontal == true){
			// Set the first cell of the boat	
			myGrid[x][y] = " < ";
			// Set the remaining cells of the boat
			for (int i = 1; i < currentShip-1; i++){	
				myGrid[x][y+i] = " = ";	
			}
			// Set the final cell of the boat
			myGrid[x][y+currentShip-1] = " > ";
		}
		else if (horizontal == false){
			// Set the first cell of the boat	
			myGrid[x][y] = " ^ ";
			// Set the remaining cells of the boat
			for (int i = 1; i < currentShip-1; i++){	
				myGrid[x+i][y] = " | ";	
			}
			// Set the final cell of the boat
			myGrid[x+currentShip-1][y] = " ^ ";
		}
		
	}
		
	/** Method which updates the tracking grid after
	 *  a player has taken a shot.
	 * @param x X-position of the shot
	 * @param y Y-position of the shot
	 * @param symb The symbol to represent either a hit or a miss
	 */
	public void takeAShot(int x, int y, String symb){
		 trackingGrid[x][y] = symb;
	}
	
	/**
	 *  Method which updates the players own grid after
	 *  they receive a hit.
	 * @param x X-position of the shot
	 * @param y Y-position of the shot
	 * @param symb The symbol to represent either a hit or a miss
	 */
	public void receiveHit(int x, int y, String symb){
		myGrid[x][y] = symb;
	}
	
	/**
	 *  Method that checks whether a player has been hit
	 * @param x X-position of the shot
	 * @param y Y-position of the shot
	 * @return Either a 1 or a 0 depending on whether they were hit or not
	 */
	public int wasIHit(int x, int y){
		if (myGrid[x][y].equals("   ")){
			return 0;	
		}
		else{
			return 1;
		}
	}

	/**
	 *  Method to return the players own grid
	 * @return players grid
	 */
	public String[][] playerGrid(){
		return myGrid;
	}
	
	/**
	 *  Method to return the players tracking grid
	 * @return players grid
	 */
	public String[][] playerTracker(){
		return trackingGrid;
	}
	
	/**
	 * Method to return the array of ships
	 * @return ship array
	 */
	public int[] getShipArray(){
		return ships;
	}
	
	
	/**
	 *  Method used during testing only to print the players own grid
	 */
	public void printMyGrid(){
		int i = 0;
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		for (int j = 0; j<rows; j++){
			for ( i = 0; i < cols; i ++){
				System.out.print(myGrid[j][i]);
			}
			System.out.println("");
			i = 0;
		}
	}
	
	/**
	 *  Method used during testing only to print the tracking grid
	 */
	public void printMyTracking(){
		int i = 0;
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		for (int j = 0; j<rows; j++){
			for ( i = 0; i < cols; i ++){
				System.out.print(trackingGrid[j][i]);
			}
			System.out.println("");
			i = 0;
		}
	}
}