import javax.swing.JOptionPane;

/**
 * The main Class
 * @author Susie Smart
 *
 */
public class Main {

	public static void main(String[] args) {
		
		// Create the GamePlay object and two instances of the GUI, one for each player
		GamePlay play = new GamePlay();
		GameGUI guiP1 = new GameGUI(1, play);
		GameGUI guiP2 = new GameGUI(2, play);
		
		// Play the game until someone wins. Continue to swap who's GUI is displayed
		while (guiP1.getTotalHits() < 17 &&  guiP2.getTotalHits() < 17){
			 while(play.getTurn() == 1 ){
				 guiP1.setVisible(true);
				 guiP2.setVisible(false); 
			 }
			 while(play.getTurn() == 2 ){
				 guiP1.setVisible(false);
				 guiP2.setVisible(true); 
			 }
		 }
		// Displays message when someone wins the game
		JOptionPane.showMessageDialog(null, "The winner was Player"+play.getTurn());
	}		
}
