import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

/**
 * This class contains the GUI and view
 * @author Susie Smart
 *
 */

public class  GameGUI extends JFrame implements ActionListener {
	
	// Instance variables
	private int player, numOfShips, totalHits, swaps;
	private GamePlay game;
	private JButton swap;
	private ButtonGroup group;
	private JRadioButton horizontal, vertical;
	private JLabel directions, notify;
	private JTable tableGrid, tableTrack;
	private boolean turnTaken, direction;

	/**
	 * Game GUI constructor
	 * @param p Integer representing either player 1 or 2
	 * @param g GamePlay object
	 */
	public GameGUI(int p, GamePlay g) {
		
		// Initialise variables
		player = p;
		game = g;
		turnTaken = false;
		swaps = 0;
		totalHits = 0;
		numOfShips = game.getNoOfShips();

		// Set the display settings
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// Location changes slightly between players so that it is clear when the GUIs swap
		setLocation(100*player,100);
		setTitle("PLAYER "+player+"'s TURN");
		setSize(250, 750);
		// Create GUI Grid layout
		GridLayout guiGrid = new GridLayout(4,1);
		setLayout(guiGrid);
		// Layout the grid components
		layoutGrid();
		// Set the display visible
		this.setVisible(true);
	
	}
	/**
	 *  Method which lays out each of the Jpanels onto the
	 *  main grid layout
	 */
	public void layoutGrid(){

		// Create all required JPanels for each row of the grid layout		
		JPanel guiPane1 = new JPanel(new BorderLayout());
		JPanel guiPane2 = new JPanel(new GridLayout(5,1));
		JPanel guiPane3 = new JPanel(new BorderLayout());
		JPanel guiPane4 = new JPanel(new GridLayout(5,1));
		
		// Initialise two tables that represent both the players own 
		// grid and their tracking grid
		initialiseTables();
		
		// Create a label as a heading to the players own grid
		// Add both the heading and the players own grid to the first JPanel
		JLabel heading1 = new JLabel("YOUR OWN GRID");
		JLabel buttonHeading1 = new JLabel ("Horizontal");
		JLabel buttonHeading2 = new JLabel ("Vertical");
		horizontal = new JRadioButton();
		vertical = new JRadioButton();
		guiPane1.add(heading1, BorderLayout.NORTH);
		guiPane1.add(tableGrid, BorderLayout.CENTER);
		
		
		// Create a label that will give the user directions throughout the game
		directions = new JLabel("Place your "+5+" unit long ship in position");
		guiPane2.add(directions);
		// Add Radio buttons for selection of horizontal or vertical placement
		guiPane2.add(buttonHeading1);
		guiPane2.add(horizontal);
		guiPane2.add(buttonHeading2);
		guiPane2.add(vertical);
		
		// Create a label as a heading to the players tracking grid
		// Add both the heading and the players tracking grid to the second JPanel
		JLabel heading = new JLabel("YOUR TRACKING GRID");
		guiPane3.add(heading, BorderLayout.NORTH);
		guiPane3.add(tableTrack, BorderLayout.CENTER);

		// Create a button to let user swap turns
		swap = new JButton("Swap Player");
		swap.setEnabled(false);
		// Create a label which will notify the user if they hit or miss their opponent
		notify = new JLabel("");
		// Add the last components to the last JPanel
		guiPane4.add(swap, BorderLayout.CENTER);
		guiPane4.add(notify, BorderLayout.SOUTH);
		
		// Add the three JPanels to the main frame
		this.add(guiPane1);
		this.add(guiPane2);
		this.add(guiPane3);
		this.add(guiPane4);

		// Add action listeners to the swap button
		swap.addActionListener(this);
		// Group radio buttons so that only one can be pressed at a time
		group = new ButtonGroup();
		group.add(horizontal);
		group.add(vertical);

		// Methods which listen for the user selecting their ship or shot positions
		getShipPostions();
		getShotPosition();			
	}
	

	/**
	 * Method which returns the players total number of hits.
	 * This can be used to determine who has won.
	 * @return Integer of number of hits
	 */
	public int getTotalHits(){
		return totalHits;
	}

	/**
	 *  Method which updates the tables on the display
	 */
	public void initialiseTables(){
		// Get the players own grid and create an array of empty headings
		String[][] data = game.getMyGrid(player);
	
		String[] headings = new String [data.length];
		for (int i =0; i < data.length; i++){
			headings[i] = "";
		}
		// Update table grid
		tableGrid = new JTable(data, headings);

		// Get the players tracking grid and create an array of empty headings
		String[][] dataTrack = game.getMyTracker(player);
		String[] headingsTrack = new String [dataTrack.length];
		for (int i =0; i < data.length; i++){
			headingsTrack[i] = "";
		}
		// Update the tracking grid
		tableTrack = new JTable(dataTrack, headingsTrack);
	}
	
	/**
	 *  Method which listens to the first mouse clicks
	 *  and adds ships to the selected cell
	 */
	public void getShipPostions(){
		tableGrid.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {
				  
				  int x = 0;
				  int y = 0;
				  
				  // Get the number of ships already placed
				  int shipsPlaced = game.getPlacementCount(player);
	
				  // If not all the ships have been placed then get the selected x and y co-ordinates
				  if (shipsPlaced<numOfShips){
					  if (isDirSelected() == true){
						  	tableGrid = (JTable)e.getSource();
				      		x = tableGrid.getSelectedRow();
				      		y = tableGrid.getSelectedColumn();
				      		// Use the x and y coordinates and direction to place the ship
				      		game.layoutShips(player, x, y, direction);
				      		tableGrid.repaint();
				      		//Update the instructions.
						  	if (shipsPlaced<numOfShips-1){
						  		int length = game.getShipLength(player, shipsPlaced+1);
						  		directions.setText("Place your "+length+" unit long ship in position");
						  	}
						}
				  }
				  else {
					  // Once all the boats have been placed let the user swap the turn
					  directions.setText("Now press swap to let your oponent play"); 
					  swap.setEnabled(true);
					  group.clearSelection();
				  }  
 	                                                       
			  	}
			});
	}
	
	/**
	 * Method which allows the user to select a square in the table
	 * to take a shot
	 */
	public void getShotPosition(){
		tableTrack.addMouseListener(new MouseAdapter() {
			  public void mouseClicked(MouseEvent e) {

				  // Check if the player has had their turn, if they have not then let them take a shot
				  if (turnTaken == false){
					  // Count how many shots they have taken
					  int shotsTaken = game.getPlacementCount(player);
					  
					  // Only allow the player to take a shot after all the ships have been placed and then get the selected x and y coordinates
					  if (shotsTaken>numOfShips){
						  tableTrack = (JTable)e.getSource();
						  int x = tableTrack.getSelectedRow();
						  int y = tableTrack.getSelectedColumn();
						  // Game player turn will return a 0 or a 1 depending on whether it was a hit or a miss
						  int temp = game.playerTurn(player, x, y);
						  if (temp == 0){
							  notify.setText("It was a miss!"); 
							  turnTaken = true;
							  directions.setText("Now press swap to let your oponent play");
							  swap.setEnabled(true);
						  }
				      	  else if (temp == 1){
				      		  totalHits++;
				      		  notify.setText("It was a hit!"); 
				      		  turnTaken = true;
				      		  directions.setText("Now press swap to let your oponent play");
				      		  swap.setEnabled(true);
				      	  }
				      	  else{
				      		  turnTaken = false;
				      	  }
						// Update the tables after the shots have been fired and received
				      	tableTrack.repaint();;
				      
					  }
					} 
			  }  
			  });
	}
	
	/**
	 * Method to set whether the user has selected to place their ship
	 *  horizontally or vertically
	 */
	public boolean isDirSelected(){
		
		if (horizontal.isSelected()){
			direction = true;
		}
		else if (vertical.isSelected()){
			direction = false;
		}
		else {
			JOptionPane.showMessageDialog(null,"Please select a direction", "Input Error",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
		
	}
		
	/**
	 * Method which listens for the user pressing the swap button
	 */
	public void actionPerformed(ActionEvent e) {

		// If the swap button is pressed swap the current turn
		if (e.getSource()==swap){
			// Also check that it is not the first swap then let the user take a shot
			if (swaps > 0){
				turnTaken = false;
				directions.setText("Take A shot");
			}
			swap.setEnabled(false);
			swaps++;
			game.swapTurn(player);
			game.addToCount(player);	
		}
	}
}

	