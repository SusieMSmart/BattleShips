The Battle Ships game has been implemented using Java.
## Goal
The program provided meets the functional requirements fully however there are some minor deficiencies in the design. The game is a two-player game, however at this point the game can only be played on one machine. This means that players must look away when it is not their turn. If I were to develop the game further I would explore the potential of implementing the game over a distributed network so that two people could play from different locations.
There is also a small issue where the length of the ship described in the instructions text on the GUI decreases from 5 to 4 when the user tries to place the first ship too near the edge. In this case the length should not be decremented and the user should try again. This is a minor issue that a short time de-bugging should fix.
As the program is relatively simple it was manageable to test the full functionality in a reasonable timescale. If further features were added to the game and its complexity grew I would look into using automated testing techniques.
## Requirements
The requirements have been achieved by implementing a typical model view controller system architecture. In this case the GamePlay class acts as the controller, the GameGUI class as the view and the Player class as the model.

### Build a board

Each player object has a 10 x 10 2D array of Strings which represents the players board. The cells in the array are either empty strings or they can contain the symbols that represent a ship.

### Tracking board

Each player object has a 10 x 10 2D array of Strings which represents the players tracking board. The cells in the array are either empty strings or they can contain the symbols that represent a hit or a miss.

The tracking grid of one player is updated with the same x-y coordinates as the opponents playing grid.


### Validate layout

The board design has been tested to show that a player cannot place a ship that will extend off the side of the board and that a ship cannot be placed on top of an existing ship.
The boards have been tested to ensure that both the players tracking grid and opponents playing grid update correctly when shots are fired.
The program also checks that a player has not tried to fire a shot in a position where they have already taken a previous shot.

### Determine winner

The game is controlled by the user who is able to select to swap players at key points in the game. This button is disabled until the player has positioned all of their boats. Then it is disabled again until they take a shot in each round. The tracking grid is also disabled after they have had their shot.

The winner is calculated by keeping track of each player�s number of successful shots on target. When this is equal to 17 the winner is announced. Further work could be down to provide options to start a new game at this point.
